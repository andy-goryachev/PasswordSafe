package org.bouncycastle.pqc.crypto.ntru;

public class NTRUParameters
{
    public static final int TERNARY_POLYNOMIAL_TYPE_SIMPLE = 0;
    public static final int TERNARY_POLYNOMIAL_TYPE_PRODUCT = 1;
}
