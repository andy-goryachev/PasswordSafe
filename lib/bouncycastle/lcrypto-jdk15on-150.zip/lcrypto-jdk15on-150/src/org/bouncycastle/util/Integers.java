package org.bouncycastle.util;

public class Integers
{
    public static Integer valueOf(int value)
    {
        return Integer.valueOf(value);
    }
}
